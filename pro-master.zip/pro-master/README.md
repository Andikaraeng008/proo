<b>FOLLOW FACEBOOK GW COK

https://fb.com/Rizky.Rasata

<b>PERINTAH/COMMAND

• pkg update && upgrade

• pkg install git

• pkg install python2

• git clone https://github.com/RIZKY4/pro

• cd pro

• python2 pro.py
